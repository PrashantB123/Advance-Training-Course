package program3a;

public abstract class Instrument {
    public abstract void Play();
    
}